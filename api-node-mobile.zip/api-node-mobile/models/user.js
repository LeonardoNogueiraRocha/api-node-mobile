const{ Sequelize, Datatype } = require('sequelize')
const sequelize = require('.../config/database');

const User = sequelize.define('Users', {
    id: {
        type: Datatypes.UUIDV4,
        primaryKey: true
    },
    username: {
        type: Datatypes.STRING,
        allowNull: false
    },
    password: {
        type: Datatypes.STRING,
        allowNull: false
    },
    email: {
        type: Datatypes.STRING,
        allowNull: false
    }

})

modules.exports = Users;