const bcrypt = require('bcrypt');
const UserRepository = require('.../repositories/userRepository');

const SECRET_KEY = 'SUACHAVESECRETA';

class UserService{
    async register(username, password, email){
        if(this.getByUserName(username)){
            throw new Error('Usuário não cadastrado');
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await UserRepository.createUSer({username, email, password: hashedPassword});
        return user; 
    }

    async getByUserName(username){
        return await UserRepository.findByUserName(username);
    }

    async login(username, password){
        const user = this.getByUserName(username);
        if(!user){
            throw new Error('Usuário ou senha incorretos')
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const isPassordValid = await bcrypt.compare(hashedPassword, user.password);
        if(!isPassordValid){
            throw new Error('Usuário ou senha incorretos');
        }

        return true;
    }

    async getUsers(){
        return await userReporsitory.findAll();
    }
}

module.exports = new UserService();